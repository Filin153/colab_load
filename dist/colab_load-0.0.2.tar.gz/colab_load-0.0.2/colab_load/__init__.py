"""

Load .ipynb from colab (colab_load) v.0.0.1

@GusGus153

"""


from .take_file import *
from .check_func import *
from .load import *